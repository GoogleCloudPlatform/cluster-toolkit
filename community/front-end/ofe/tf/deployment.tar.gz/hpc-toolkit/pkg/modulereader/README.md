# modulereader package

The resource reader (modulereader) package reads in modules from different
sources and provides information about them to the blueprint engine.
