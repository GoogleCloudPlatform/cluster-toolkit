# config package

The config package manages the import, validation and conversion of the user
provided YAML config.
