# modulewriter package

The resource writer (modulewriter) package writes various kinds of modules to
the deployment directory and ties them together with top-level deployment files,
for example the top level `main.tf` file for terraform modules.
